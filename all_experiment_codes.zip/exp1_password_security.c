
// Program 1: Hiding password input with asterisks
#include <conio.h>
#include <stdio.h>

int main() {
    int i = 0;
    char charact;
    char password[30];

    printf("\nEnter Password : ");
    while ((charact = getch()) != 13) {
        password[i] = charact;
        i++;
        printf("*");
    }
    password[i] = '\0';
    printf("\nYour Password = %s", password);
    getch();
    return 0;
}

// Program 2: Password check loop
#include <stdio.h>

int main() {
    int pass, x = 10;

    while (x != 0) {
        printf("\nInput the password: ");
        scanf("%d", &pass);

        if (pass == 1234) {
            printf("Correct password");
            x = 0;
        } else {
            printf("Wrong password, try another");
        }
        printf("\n");
    }
    return 0;
}

// Program 3: Username and password verification
#include <stdio.h>
#include <string.h>
#include <conio.h>

int main() {
    char username[15];
    char password[12];
    printf("Enter your username:\n");
    scanf("%s", username);
    printf("Enter your password:\n");
    scanf("%s", password);

    if (strcmp(username, "admin") == 0) {
        if (strcmp(password, "admin") == 0) {
            printf("\nWelcome. Login Success!");
        } else {
            printf("\nWrong password");
        }
    } else {
        printf("\nUser doesn't exist");
    }
    return 0;
}
