
#include <stdio.h>
#include <ctype.h>

int main() {
    char text[500], ch;
    int key, i;

    printf("Enter a message to encrypt: ");
    scanf("%s", text);
    printf("Enter the key: ");
    scanf("%d", &key);
    printf("\nEncrypted message is:==>");

    for (i = 0; isalnum(text[i]) != 0 && text[i] != '\0'; ++i) {
        ch = text[i];
        if (islower(ch)) {
            ch = (ch - 'a' + key) % 26 + 'a';
        }
        if (isupper(ch)) {
            ch = (ch - 'A' + key) % 26 + 'A';
        }
        if (isdigit(ch)) {
            ch = (ch - '0' + key) % 10 + '0';
        }
        text[i] = ch;
        printf("%c", text[i]);
    }
    printf("\nWe have not encrypted non-alphanumeric characters if present in the message\n");
    return 0;
}

// Decryption
#include <stdio.h>
#include <ctype.h>

int main() {
    char text[500], ch;
    int key;

    printf("Enter a message to decrypt: ");
    scanf("%s", text);
    printf("Enter the key: ");
    scanf("%d", &key);

    for (int i = 0; text[i] != '\0'; ++i) {
        ch = text[i];
        if (isalnum(ch)) {
            if (islower(ch)) {
                ch = (ch - 'a' - key + 26) % 26 + 'a';
            }
            if (isupper(ch)) {
                ch = (ch - 'A' - key + 26) % 26 + 'A';
            }
            if (isdigit(ch)) {
                ch = (ch - '0' - key + 10) % 10 + '0';
            }
        } else {
            printf("Invalid Message");
        }
        text[i] = ch;
    }
    printf("Decrypted message: %s", text);
    return 0;
}
